#include "framework.h"
#include "CannonScene.h"

void CannonScene::Update()
{
}

void CannonScene::Render(HDC hdc)
{
}
