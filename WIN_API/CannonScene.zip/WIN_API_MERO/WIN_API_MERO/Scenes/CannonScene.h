#pragma once
class CannonScene : public Scene
{
public:
	void Update() override;
	void Render(HDC hdc) override;

private:
};

